package com.khvpn.app;
import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import androidx.activity.result.ActivityResult;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.InetSocketAddress;
import java.net.Socket;

@CapacitorPlugin(name = "KhVpn")
public class KhVpnPlugin extends Plugin {
  @Override public void load() {
    KhVpnService.listener = (s, m) -> notifyListeners("state", new JSObject().put("state", s).put("message", m));
  }

  @PluginMethod public void connect(PluginCall call) {
    Intent i = VpnService.prepare(getContext());
    if (i != null) startActivityForResult(call, i, "onPerm"); else start(call);
  }

  @ActivityCallback private void onPerm(PluginCall call, ActivityResult r) {
    if (call == null) return;
    if (r.getResultCode() == Activity.RESULT_OK) start(call); else call.reject("Izin VPN ditolak");
  }

  private void start(PluginCall call) {
    Intent i = new Intent(getContext(), KhVpnService.class).setAction("start").putExtra("cfg", call.getData().toString());
    ContextCompat.startForegroundService(getContext(), i);
    call.resolve();
  }

  @PluginMethod public void disconnect(PluginCall call) {
    getContext().startService(new Intent(getContext(), KhVpnService.class).setAction("stop"));
    call.resolve();
  }

  @PluginMethod public void ping(PluginCall call) {
    final String h = call.getString("host"); final int p = call.getInt("port", 22);
    new Thread(() -> {
      long t = System.nanoTime();
      try (Socket s = new Socket()) {
        s.connect(new InetSocketAddress(h, p), 5000);
        call.resolve(new JSObject().put("ms", (System.nanoTime() - t) / 1000000));
      } catch (Exception e) { call.reject(String.valueOf(e.getMessage())); }
    }).start();
  }
}
