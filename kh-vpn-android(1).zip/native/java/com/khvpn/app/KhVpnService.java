package com.khvpn.app;
import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.*;
import android.os.*;
import com.trilead.ssh2.Connection;
import hev.htproxy.TProxyService;
import java.io.*;
import java.net.InetSocketAddress;
import java.util.concurrent.CountDownLatch;
import org.json.*;

public class KhVpnService extends VpnService {
  public interface Listener { void on(String state, String msg); }
  public static volatile Listener listener;
  static void emit(String s, String m) { Listener l = listener; if (l != null) l.on(s, m); }

  private volatile boolean running;
  private volatile CountDownLatch lost = new CountDownLatch(1);
  private Thread worker;
  private ParcelFileDescriptor tun;
  private Process dnstt;
  private Connection conn;
  private boolean tproxy;

  @Override public int onStartCommand(Intent i, int flags, int id) {
    if (i != null && "stop".equals(i.getAction())) { halt(); return START_NOT_STICKY; }
    fg();
    halt();
    try {
      final JSONObject cfg = new JSONObject(i.getStringExtra("cfg"));
      running = true;
      worker = new Thread(() -> loop(cfg));
      worker.start();
    } catch (Exception e) { emit("error", "Konfigurasi tidak valid: " + e.getMessage()); stopSelf(); }
    return START_NOT_STICKY;
  }

  private void halt() {
    running = false; release();
    Thread w = worker;
    if (w != null) { w.interrupt(); try { w.join(4000); } catch (InterruptedException ignored) {} }
  }

  private void release() { CountDownLatch l = lost; if (l != null) l.countDown(); }

  @Override public void onRevoke() { halt(); }
  @Override public void onDestroy() { halt(); super.onDestroy(); }

  private void fg() {
    NotificationManager nm = getSystemService(NotificationManager.class);
    Notification.Builder b;
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(new NotificationChannel("vpn", "Kh vpn", NotificationManager.IMPORTANCE_LOW));
      b = new Notification.Builder(this, "vpn");
    } else b = new Notification.Builder(this);
    Notification n = b.setContentTitle("Kh vpn").setContentText("Tunnel aktif").setSmallIcon(android.R.drawable.ic_lock_lock).build();
    if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED);
    else startForeground(1, n);
  }

  private void loop(JSONObject c) {
    ConnectivityManager cm = getSystemService(ConnectivityManager.class);
    final Network[] last = {null};
    ConnectivityManager.NetworkCallback cb = new ConnectivityManager.NetworkCallback() {
      @Override public void onAvailable(Network n) {
        if (last[0] != null && !n.equals(last[0]) && c.optBoolean("detect", true)) { emit("warn", "Jaringan berganti (provider/Wi-Fi)"); release(); }
        last[0] = n;
      }
      @Override public void onLost(Network n) {
        if (n.equals(last[0]) && c.optBoolean("detect", true)) { emit("warn", "Jaringan hilang"); release(); }
      }
    };
    try {
      cm.registerDefaultNetworkCallback(cb);
      boolean auto = c.optBoolean("auto", true);
      int max = c.optInt("maxRetries", 10), delay = c.optInt("delaySec", 3), attempt = 0;
      JSONArray fb = c.optJSONArray("fallbacks");
      while (running) {
        String res = c.optString("resolver", "1.1.1.1:53");
        if (attempt > 0 && fb != null && fb.length() > 0) res = fb.optString(attempt % fb.length(), res);
        emit(attempt > 0 ? "reconnecting" : "connecting", "Menghubungkan (percobaan " + (attempt + 1) + ")...");
        lost = new CountDownLatch(1);
        try {
          open(c, res);
          attempt = 0;
          emit("connected", "Tunnel aktif");
          lost.await();
        } catch (InterruptedException ie) { break; }
        catch (Throwable e) { emit("error", String.valueOf(e.getMessage())); }
        closeSession();
        if (!running || !auto) break;
        attempt++;
        if (max > 0 && attempt > max) { emit("failed", "Batas percobaan ulang tercapai"); break; }
        try { Thread.sleep(delay * 1000L); } catch (InterruptedException ie) { break; }
      }
    } catch (Throwable t) { emit("error", String.valueOf(t.getMessage())); }
    finally {
      try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) {}
      running = false; closeSession();
      emit("disconnected", "Terputus");
      stopForeground(true); stopSelf();
    }
  }

  private void open(JSONObject c, String res) throws Exception {
    String host = c.getString("host"); int port = c.optInt("port", 22);
    if (!"ssh-direct".equals(c.optString("mode"))) {
      File dir = new File(getApplicationInfo().nativeLibraryDir);
      File slip = new File(dir, "libslipstream.so"), bin = new File(dir, "libdnstt.so");
      String proto = c.optString("protocol", "slipstream"), tr = c.optString("transport", "udp");
      if ("slipstream".equals(proto) && !slip.exists()) { emit("warn", "Slipstream tidak ada di APK, beralih ke dnstt"); proto = "dnstt"; }
      ProcessBuilder pb;
      if ("slipstream".equals(proto)) {
        pb = new ProcessBuilder(slip.getPath(), "--tcp-listen-port", "2222", "--resolver", res, "--domain", c.getString("ns"), "--congestion-control", "bbr");
      } else {
        if (!bin.exists()) throw new IOException("libdnstt.so tidak ada di APK (ABI tidak didukung?)");
        if (c.optString("pubkey").isEmpty()) throw new IOException("Public key dnstt kosong");
        String flag = "doh".equals(tr) ? "-doh" : "dot".equals(tr) ? "-dot" : "-udp";
        pb = new ProcessBuilder(bin.getPath(), flag, res, "-pubkey", c.getString("pubkey"), c.getString("ns"), "127.0.0.1:2222");
      }
      emit("log", "SlowDNS: " + proto + ("dnstt".equals(proto) ? " via " + tr : ""));
      dnstt = pb.redirectErrorStream(true).start();
      final Process p = dnstt;
      new Thread(() -> { try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) { String l; while ((l = r.readLine()) != null) emit("log", "slowdns: " + l); } catch (IOException ignored) {} }).start();
      Thread.sleep(1500);
      try { throw new IOException("SlowDNS berhenti (kode " + p.exitValue() + ") — cek NS, resolver, dan public key"); } catch (IllegalThreadStateException alive) {}
      host = "127.0.0.1"; port = 2222;
    }
    Connection s = new Connection(host, port);
    s.setTCPNoDelay(c.optBoolean("tcpNoDelay", true));
    s.connect(null, 30000, 30000);
    if (!s.authenticateWithPassword(c.getString("user"), c.getString("pass"))) { s.close(); throw new IOException("Login SSH ditolak (user/password salah)"); }
    s.addConnectionMonitor(t -> { emit("warn", "SSH terputus: " + t); release(); });
    s.createDynamicPortForwarder(new InetSocketAddress("127.0.0.1", 1080));
    conn = s;
    final int ka = c.optInt("keepAlive", 15);
    if (ka > 0) new Thread(() -> { try { while (conn == s && running) { Thread.sleep(ka * 1000L); s.sendIgnorePacket(); } } catch (Exception e) { release(); } }).start();

    int mtu = c.optInt("mtu", 1380);
    Builder b = new Builder().setSession("Kh vpn").setMtu(mtu).addAddress("10.0.0.2", 32).addRoute("0.0.0.0", 0).addDnsServer("198.18.0.2");
    try { b.addDisallowedApplication(getPackageName()); } catch (Exception ignored) {}
    tun = b.establish();
    if (tun == null) throw new IOException("Izin VPN dicabut");
    String yml = "tunnel:\n  mtu: " + mtu + "\n  ipv4: 10.0.0.2\nsocks5:\n  port: 1080\n  address: 127.0.0.1\n"
      + "mapdns:\n  address: 198.18.0.2\n  port: 53\n  network: 100.64.0.0\n  netmask: 240.0.0.0\n  cache-size: 10000\n"
      + "misc:\n  task-stack-size: 81920\n";
    File f = new File(getFilesDir(), "hev.yml");
    try (FileWriter w = new FileWriter(f)) { w.write(yml); }
    TProxyService.TProxyStartService(f.getAbsolutePath(), tun.getFd());
    tproxy = true;
  }

  private synchronized void closeSession() {
    if (tproxy) { try { TProxyService.TProxyStopService(); } catch (Throwable ignored) {} tproxy = false; }
    if (tun != null) { try { tun.close(); } catch (IOException ignored) {} tun = null; }
    if (conn != null) { conn.close(); conn = null; }
    if (dnstt != null) { dnstt.destroy(); dnstt = null; }
  }
}
